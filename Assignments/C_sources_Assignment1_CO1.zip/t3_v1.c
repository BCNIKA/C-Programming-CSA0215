#include <stdio.h>

int main(void)
{
    printf("==== SMART CAMPUS UTILITY BILLING SYSTEM ====\n");
    return 0;
}
