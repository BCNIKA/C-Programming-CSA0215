#include <stdio.h>

#define SERVICE_PERCENT  5.0
#define HIGH_USAGE_UNITS 200             /* assumed threshold, used for this demo only */

int main(void)
{
    int    a = 17, b = 5;
    int    units = 150, slab = 100, total_units = 275;
    double rate = 8.50, subtotal, service_charge;
    int    high_usage, valid_record, p, q, hits;
    char   facility_id[] = "LIB01";

    printf("--- Arithmetic operators (a = 17, b = 5) ---\n");
    printf("a + b = %d, a - b = %d, a * b = %d\n", a + b, a - b, a * b);
    printf("a / b = %d (integer), a %% b = %d, (double)a / b = %.2f\n", a / b, a % b, (double)a / b);
    printf("275 units in slabs of 100: full slabs = %d, remaining units = %d\n",
           total_units / slab, total_units % slab);

    printf("--- Billing calculation ---\n");
    subtotal       = units * rate;
    service_charge = subtotal * SERVICE_PERCENT / 100.0;
    printf("subtotal = %.2f, service charge = %.2f, final = %.2f\n",
           subtotal, service_charge, subtotal + service_charge);

    printf("--- Relational and logical operators ---\n");
    high_usage   = units > HIGH_USAGE_UNITS;
    valid_record = (facility_id[0] != '\0') && (units >= 0) && (rate >= 0.0);
    printf("units > %d          -> %d\n", HIGH_USAGE_UNITS, high_usage);
    printf("valid billing record -> %d\n", valid_record);

    printf("--- Truth table ---\n");
    printf(" p q | p&&q p||q !p\n");
    for (p = 0; p <= 1; p++) {
        for (q = 0; q <= 1; q++) {
            printf(" %d %d |  %d    %d    %d\n", p, q, p && q, p || q, !p);
        }
    }

    printf("--- Short-circuit evaluation ---\n");
    hits = 0;
    (void)((units < 0) && (++hits > 0));       /* left side false -> right side skipped */
    printf("false && (++hits > 0): hits = %d\n", hits);
    (void)((units >= 0) || (++hits > 0));      /* left side true  -> right side skipped */
    printf("true  || (++hits > 0): hits = %d\n", hits);
    (void)((units >= 0) && (++hits > 0));      /* left side true  -> right side evaluated */
    printf("true  && (++hits > 0): hits = %d\n", hits);
    {
        int divisor = 0;
        if ((divisor != 0) && (100 / divisor > 2)) {
            printf("not reached\n");
        } else {
            printf("divisor = 0: division skipped safely by &&\n");
        }
    }

    printf("--- Five traced expressions (units = 150, rate = 8.50) ---\n");
    printf("E1 units * rate                       = %.2f\n", units * rate);
    printf("E2 units * rate * 5.0 / 100.0         = %.2f\n", units * rate * SERVICE_PERCENT / 100.0);
    printf("E3 units > 200                        = %d\n", units > 200);
    printf("E4 (units >= 0) && (rate >= 0.0)      = %d\n", (units >= 0) && (rate >= 0.0));
    printf("E5 !(units > 200) || (rate < 0.0)     = %d\n", !(units > 200) || (rate < 0.0));
    printf("E6 275 %% 100 + 275 / 100              = %d\n", 275 % 100 + 275 / 100);
    return 0;
}
