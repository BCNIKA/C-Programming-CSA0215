#include <stdio.h>
int main(void)
{
    int meter = 150;                      /* current meter reading */
    meter = meter++ + 10;                 /* intent: add 10; but meter is modified twice */
    printf("%d\n", meter);
    return 0;
}
