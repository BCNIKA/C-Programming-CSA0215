#include <stdio.h>

#define SERVICE_PERCENT 5.0

static int is_valid_record(int units, double rate)
{
    return (units >= 0) && (rate >= 0.0);
}

static double calc_subtotal(int units, double rate)
{
    return units * rate;
}

static double calc_service_charge(double subtotal)
{
    return subtotal * SERVICE_PERCENT / 100.0;
}

static double calc_final_bill(int units, double rate)
{
    double subtotal = calc_subtotal(units, rate);
    return subtotal + calc_service_charge(subtotal);
}

#ifdef SELF_TEST                          /* compile with -DSELF_TEST to run the unit tests */
static int nearly_equal(double a, double b)
{
    double diff = a - b;
    if (diff < 0.0) {
        diff = -diff;
    }
    return diff < 0.005;
}

static int check(const char *name, int condition)
{
    printf("%-40s : %s\n", name, condition ? "PASS" : "FAIL");
    return condition ? 0 : 1;
}

int main(void)
{
    int failures = 0;
    failures += check("calc_subtotal(150, 8.50) = 1275.00", nearly_equal(calc_subtotal(150, 8.50), 1275.00));
    failures += check("calc_service_charge(1275) = 63.75", nearly_equal(calc_service_charge(1275.00), 63.75));
    failures += check("calc_final_bill(150, 8.50) = 1338.75", nearly_equal(calc_final_bill(150, 8.50), 1338.75));
    failures += check("calc_final_bill(0, 8.50) = 0.00", nearly_equal(calc_final_bill(0, 8.50), 0.0));
    failures += check("is_valid_record(-1, 5.0) is false", !is_valid_record(-1, 5.0));
    failures += check("is_valid_record(5, -0.5) is false", !is_valid_record(5, -0.5));
    failures += check("is_valid_record(0, 0.0) is true", is_valid_record(0, 0.0));
    printf("Failures: %d\n", failures);
    return failures;
}
#else
int main(void)
{
    int    units;
    double rate;

    printf("Enter units and rate:\n");
    if (scanf("%d %lf", &units, &rate) != 2) {
        printf("ERROR: invalid input.\n");
        return 1;
    }
    if (!is_valid_record(units, rate)) {
        printf("ERROR: negative value.\n");
        return 1;
    }
    printf("Subtotal : %.2f\n", calc_subtotal(units, rate));
    printf("Service  : %.2f\n", calc_service_charge(calc_subtotal(units, rate)));
    printf("Final    : %.2f\n", calc_final_bill(units, rate));
    return 0;
}
#endif
