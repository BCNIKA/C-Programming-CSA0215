#define SERVICE_PERCENT 5.0
static const int BILLING_VERSION = 1;
