#include <stdio.h>

#define HIGH_BILL_LIMIT 5250.00          /* assumed threshold: bill ABOVE this is HIGH */

int main(void)
{
    double bill = 1000.0;
    int    x = 5, y;
    double test_bills[3] = {1338.75, 5250.00, 5260.50};
    int    i;

    printf("--- Compound assignment on a bill (start 1000.00) ---\n");
    bill += 50.0;   printf("bill += 50.0   -> %.2f  (service charge added)\n", bill);
    bill -= 105.0;  printf("bill -= 105.0  -> %.2f  (concession deducted)\n", bill);
    bill *= 2;      printf("bill *= 2      -> %.2f  (two months)\n", bill);
    bill /= 3;      printf("bill /= 3      -> %.2f  (three instalments)\n", bill);

    printf("--- Prefix / postfix trace (x starts at 5) ---\n");
    printf("start        : x = %d\n", x);
    y = x++;  printf("y = x++      : y = %d, x = %d\n", y, x);
    y = ++x;  printf("y = ++x      : y = %d, x = %d\n", y, x);
    x += 5;   printf("x += 5       : x = %d\n", x);
    y = x--;  printf("y = x--      : y = %d, x = %d\n", y, x);
    y = --x;  printf("y = --x      : y = %d, x = %d\n", y, x);

    printf("--- Conditional operator vs if-else (limit %.2f) ---\n", HIGH_BILL_LIMIT);
    for (i = 0; i < 3; i++) {
        const char *by_ternary;
        const char *by_ifelse;
        by_ternary = (test_bills[i] > HIGH_BILL_LIMIT) ? "HIGH" : "STANDARD";
        if (test_bills[i] > HIGH_BILL_LIMIT) {
            by_ifelse = "HIGH";
        } else {
            by_ifelse = "STANDARD";
        }
        printf("bill %8.2f : ?: gives %-8s | if-else gives %-8s\n",
               test_bills[i], by_ternary, by_ifelse);
    }

    printf("--- Corrected evaluation-order example ---\n");
    {
        int meter = 150;                       /* current meter reading */
        printf("before: meter = %d\n", meter);
        meter += 10;                           /* ONE modification: well defined */
        printf("after : meter = %d\n", meter);
    }
    return 0;
}
