#include <stdio.h>
#include <limits.h>
#include <float.h>

static void print_header(void)           /* void: the function returns no value */
{
    printf("--- sizeof and limits on this compiler ---\n");
}

int main(void)
{
    char facility_id[16] = "LIB01";
    int  units           = 150;
    double rate          = 8.50;
    double subtotal;
    int  whole_rupees;
    int  total_units = 7, days = 2;

    print_header();
    printf("sizeof(char)        = %zu\n", sizeof(char));
    printf("sizeof(short)       = %zu\n", sizeof(short));
    printf("sizeof(int)         = %zu\n", sizeof(int));
    printf("sizeof(unsigned)    = %zu\n", sizeof(unsigned int));
    printf("sizeof(long)        = %zu\n", sizeof(long));
    printf("sizeof(long long)   = %zu\n", sizeof(long long));
    printf("sizeof(float)       = %zu\n", sizeof(float));
    printf("sizeof(double)      = %zu\n", sizeof(double));
    printf("sizeof(long double) = %zu\n", sizeof(long double));
    printf("sizeof(facility_id) = %zu\n", sizeof(facility_id));
    printf("INT_MIN = %d, INT_MAX = %d, UINT_MAX = %u\n", INT_MIN, INT_MAX, UINT_MAX);
    printf("FLT_DIG = %d, DBL_DIG = %d\n", FLT_DIG, DBL_DIG);

    printf("--- precision: float vs double ---\n");
    printf("float  0.1 printed to 10 places : %.10f\n", (double)0.1f);
    printf("double 0.1 printed to 20 places : %.20f\n", 0.1);
    printf("float  16777217 stored as       : %.1f\n", (double)16777217.0f);

    printf("--- implicit conversion ---\n");
    subtotal = units * rate;             /* int units is converted to double */
    printf("units * rate = %d * %.2f = %.2f\n", units, rate, subtotal);

    printf("--- explicit cast ---\n");
    whole_rupees = (int)(subtotal + 0.75);    /* 1275.75 -> 1275 (fraction discarded) */
    printf("(int)(%.2f) = %d\n", subtotal + 0.75, whole_rupees);
    printf("integer division 7 / 2        = %d\n", total_units / days);
    printf("with cast (double)7 / 2       = %.2f\n", (double)total_units / days);
    return 0;
}
