#include <stdio.h>
int main(void)
{
    {
        int block_temp = 10;
    }
    printf("%d\n", block_temp);          /* block_temp is out of scope here */
    return 0;
}
