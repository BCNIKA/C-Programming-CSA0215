#ifndef SMART_CAMPUS_BILLING_H           /* include guard: unique macro name */
#define SMART_CAMPUS_BILLING_H

#define SERVICE_PERCENT 5.0              /* assumed service charge (%)            */
#define DEFAULT_RATE    8.50             /* assumed default tariff (Rs. per unit) */

static const int BILLING_VERSION = 1;    /* would be redefined if included twice  */

#endif /* SMART_CAMPUS_BILLING_H */
