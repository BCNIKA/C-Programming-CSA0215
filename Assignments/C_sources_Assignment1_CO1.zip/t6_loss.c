#include <stdio.h>
int main(void)
{
    double final_bill = 1338.75;
    int    rupees     = final_bill;     /* implicit double -> int: fraction is lost */
    printf("final_bill = %.2f, rupees = %d\n", final_bill, rupees);
    return 0;
}
