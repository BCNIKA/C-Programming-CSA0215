/* ===== 1. DOCUMENTATION SECTION =====
 * File    : t3_v2.c
 * Purpose : Read units and rate, calculate the subtotal and print it.
 */

/* ===== 2. LINK / PREPROCESSOR SECTION ===== */
#include <stdio.h>

/* ===== 3. DEFINITION SECTION ===== */
#define CURRENCY "Rs."

/* ===== 4. GLOBAL DECLARATION SECTION ===== */
static int bills_printed = 0;            /* file-scope counter */

/* ===== 5. USER-DEFINED FUNCTION ===== */
static double calculate_subtotal(int units, double rate)
{
    return units * rate;
}

/* ===== 6. main() FUNCTION ===== */
int main(void)
{
    int    units;
    double rate, subtotal;

    printf("==== SMART CAMPUS UTILITY BILLING SYSTEM ====\n");
    printf("Enter units consumed:\n");
    if (scanf("%d", &units) != 1) {
        printf("Invalid units.\n");
        return 1;
    }
    printf("Enter rate per unit:\n");
    if (scanf("%lf", &rate) != 1) {
        printf("Invalid rate.\n");
        return 1;
    }

    subtotal = calculate_subtotal(units, rate);
    bills_printed++;
    printf("Subtotal = %s %.2f\n", CURRENCY, subtotal);
    printf("Bills printed in this run: %d\n", bills_printed);
    return 0;
}
