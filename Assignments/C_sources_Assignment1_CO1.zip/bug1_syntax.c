/*
 * File       : smart_campus_bill.c
 * Purpose    : Smart Campus Utility Billing System (Assignment 1, Task 10)
 * Author     : Yashwanth Bewan A (1921260214)
 * Build      : gcc -std=c11 -Wall -Wextra -pedantic smart_campus_bill.c -o smart_campus_bill
 * Assumption : the service charge is 5% of the subtotal (assumed, not an official rule).
 */
#include <stdio.h>

#define SERVICE_PERCENT 5.0              /* named constant: service charge in percent */

int main(void)
{
    char   facility_id[16];              /* identifier, at most 15 characters         */
    int    units;                        /* whole units consumed                      */
    double rate;                         /* Rs. per unit                              */
    double subtotal, service_charge, final_bill;
    int    is_valid;                     /* 1 = valid billing record, 0 = invalid     */

    printf("=== SMART CAMPUS UTILITY BILLING SYSTEM ===\n");

    printf("Enter facility ID (no spaces):\n");
    if (scanf("%15s", facility_id) != 1) {
        printf("ERROR: facility ID is missing.\n");
        return 1;
    }
    printf("Enter units consumed (whole number):\n");
    if (scanf("%d", &units) != 1) {
        printf("ERROR: units must be a whole number.\n");
        return 1;
    }
    printf("Enter rate per unit (Rs.):\n");
    if (scanf("%lf", &rate) != 1) {
        printf("ERROR: rate must be a number.\n");
        return 1;
    }

    is_valid = (units >= 0) && (rate >= 0.0);
    if (!is_valid) {
        printf("ERROR: units and rate must not be negative.\n");
        return 1;
    }

    subtotal       = units * rate                           /* int is converted to double */
    service_charge = subtotal * SERVICE_PERCENT / 100.0;
    final_bill     = subtotal + service_charge;

    if (final_bill < 0.0) {                                 /* defensive post-condition   */
        printf("ERROR: calculated bill is negative.\n");
        return 1;
    }

    printf("\n------------- BILL SUMMARY -------------\n");
    printf("Facility ID    : %s\n", facility_id);
    printf("Units consumed : %d\n", units);
    printf("Rate per unit  : Rs. %.2f\n", rate);
    printf("Subtotal       : Rs. %.2f\n", subtotal);
    printf("Service (%.1f%%) : Rs. %.2f\n", SERVICE_PERCENT, service_charge);
    printf("FINAL BILL     : Rs. %.2f\n", final_bill);
    printf("----------------------------------------\n");
    return 0;
}
