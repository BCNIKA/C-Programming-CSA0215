#include <stdio.h>

int main(void)
{
    int    units;
    double rate;

    printf("Enter units and rate:\n");
    if (scanf("%d %lf", &units, &rate) != 2) {
        printf("ERROR: invalid input.\n");
        return 1;
    }
    if (units < 0 || rate < 0.0) {
        printf("ERROR: negative value.\n");
        return 1;
    }
    printf("Subtotal : %.2f\n", units * rate);
    printf("Service  : %.2f\n", units * rate * 5.0 / 100.0);
    printf("Final    : %.2f\n", units * rate + units * rate * 5.0 / 100.0);
    return 0;
}
