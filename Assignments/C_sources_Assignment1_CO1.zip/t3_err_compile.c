#include <stdio.h>

int main(void)
{
    int    units = 10;
    double subtotal = unit * 8.5;
    printf("%.2f\n", subtotal);
    return 0;
}
