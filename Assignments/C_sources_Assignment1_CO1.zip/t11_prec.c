#include <stdio.h>

int main(void)
{
    int    units_small = 150,     units_large = 1234567;
    float  rate_f_small = 8.50f,  rate_f_large = 12.34f;
    double rate_d_small = 8.50,   rate_d_large = 12.34;

    float  fs = units_small * rate_f_small, fl = units_large * rate_f_large;
    double ds = units_small * rate_d_small, dl = units_large * rate_d_large;

    printf("150 x 8.50      : float = %.2f | double = %.2f\n", (double)fs, ds);
    printf("1234567 x 12.34 : float = %.2f | double = %.2f\n", (double)fl, dl);
    printf("sizeof(float) = %zu, sizeof(double) = %zu\n", sizeof(float), sizeof(double));
    return 0;
}
