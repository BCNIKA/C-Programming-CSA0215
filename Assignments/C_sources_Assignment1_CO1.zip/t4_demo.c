#include <stdio.h>                       /* angle brackets: system header search path */
#include "billing.h"                     /* quotes: current directory first           */
#include "billing.h"                     /* second inclusion is harmless (guard)      */

#ifdef DEBUG_TRACE                       /* conditional compilation                   */
#define TRACE(msg) printf("[TRACE] %s\n", msg)
#else
#define TRACE(msg) ((void)0)
#endif

int main(void)
{
    int    units = 100;
    double subtotal, service;

    TRACE("program started");
    subtotal = units * DEFAULT_RATE;
    service  = subtotal * SERVICE_PERCENT / 100.0;

    printf("billing.h version : %d\n", BILLING_VERSION);
    printf("Subtotal          : Rs. %.2f\n", subtotal);
    printf("Service charge    : Rs. %.2f\n", service);
#if __STDC_VERSION__ >= 201112L
    printf("Language level    : C11 or later (__STDC_VERSION__ = %ld)\n", (long)__STDC_VERSION__);
#else
    printf("Language level    : older than C11\n");
#endif
    TRACE("program finished");
    return 0;
}
