#include <stdio.h>

#define SERVICE_PERCENT 5.0

int main(void)
{
    int    units;
    double rate, subtotal, service_charge, final_bill;

    printf("Enter units and rate:\n");
    if (scanf("%d %lf", &units, &rate) != 2) {
        printf("ERROR: invalid input.\n");
        return 1;
    }
    if (units < 0 || rate < 0.0) {
        printf("ERROR: negative value.\n");
        return 1;
    }
    subtotal       = units * rate;
    service_charge = subtotal * SERVICE_PERCENT / 100.0;
    final_bill     = subtotal + service_charge;
    printf("Subtotal : %.2f\n", subtotal);
    printf("Service  : %.2f\n", service_charge);
    printf("Final    : %.2f\n", final_bill);
    return 0;
}
