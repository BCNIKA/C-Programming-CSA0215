C source files for Assignment 1 - CO1 (Yashwanth Bewan A, 1921260214)
Build any file with:  gcc -std=c11 -Wall -Wextra -pedantic <file>.c -o <name>
Extras:  -I.  (t4_demo.c uses billing.h) | -DDEBUG_TRACE (t4_demo.c) | -DSELF_TEST (t11_mod.c)
         -DWARNING_LIMIT=1000.0 (smart_campus_bill_v2.c) | -Wconversion (t6_loss.c)
Files named t3_err_*, t4_noguard.c, t4_semicolon.c, t5_*_err.c, t5_invalid_id.c, t8_unsafe.c,
t9_ambiguous.c, t9_mistake.c and bug*.c are deliberately faulty demonstration files.
Main deliverables: smart_campus_bill.c (Task 10), smart_campus_bill_v2.c (Task 12).
