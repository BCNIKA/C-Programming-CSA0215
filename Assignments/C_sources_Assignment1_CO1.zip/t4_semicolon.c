#include <stdio.h>
#define SERVICE_PERCENT 5.0;             /* WRONG: stray semicolon */

int main(void)
{
    double subtotal = 1000.0;
    double service  = subtotal * SERVICE_PERCENT / 100.0;
    printf("%.2f\n", service);
    return 0;
}
