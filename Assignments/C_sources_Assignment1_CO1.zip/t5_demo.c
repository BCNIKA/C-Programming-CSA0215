#include <stdio.h>

#define SERVICE_PERCENT 5.0              /* constant 1: macro, replaced by the preprocessor */
#define ID_LENGTH       16

const double HIGH_BILL_LIMIT = 5250.00;  /* constant 2: typed const object, file scope      */
int bills_generated = 0;                 /* global variable: file scope, static storage     */

static void register_bill(void)
{
    int local_count = 0;                 /* local: created afresh on every call             */
    local_count++;
    bills_generated++;                   /* global: keeps its value between calls           */
    printf("register_bill(): local_count = %d, bills_generated = %d\n",
           local_count, bills_generated);
}

int main(void)
{
    char   facility_id[ID_LENGTH] = "LIB01";   /* text identifier (char array) */
    char   category   = 'A';                   /* single character             */
    int    units      = 150;                   /* integer                      */
    double rate       = 8.50;                  /* floating point               */
    double subtotal   = 0.0;
    double final_amount;

    printf("--- Integer, floating-point and character storage ---\n");
    printf("facility_id = %s, category = %c (code %d), units = %d, rate = %.2f\n",
           facility_id, category, (int)category, units, rate);

    printf("--- Initialisation vs assignment ---\n");
    subtotal     = units * rate;                          /* assignment */
    final_amount = subtotal + subtotal * SERVICE_PERCENT / 100.0;
    printf("units = %d -> subtotal = %.2f, final = %.2f\n", units, subtotal, final_amount);
    units        = 200;                                   /* new value replaces the old one */
    subtotal     = units * rate;
    final_amount = subtotal + subtotal * SERVICE_PERCENT / 100.0;
    printf("units = %d -> subtotal = %.2f, final = %.2f\n", units, subtotal, final_amount);

    printf("--- Constants ---\n");
    printf("SERVICE_PERCENT = %.1f, HIGH_BILL_LIMIT = %.2f\n", SERVICE_PERCENT, HIGH_BILL_LIMIT);

    printf("--- Scope and lifetime ---\n");
    register_bill();
    register_bill();
    register_bill();
    {
        int block_temp = units * 2;                       /* visible only inside this block */
        printf("inside block: block_temp = %d\n", block_temp);
    }
    return 0;
}
