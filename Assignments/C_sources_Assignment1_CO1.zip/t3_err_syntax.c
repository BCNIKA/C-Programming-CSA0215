#include <stdio.h>

int main(void)
{
    printf("Smart Campus Billing\n")
    return 0;
}
