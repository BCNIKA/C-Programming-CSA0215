#include <stdio.h>
const double HIGH_BILL_LIMIT = 5250.00;
int main(void)
{
    HIGH_BILL_LIMIT = 6000.00;           /* illegal: modifying a const object */
    printf("%.2f\n", HIGH_BILL_LIMIT);
    return 0;
}
