#include <stdio.h>

int main(void)
{
    int a = 10, b = 3, c = 4;

    printf("A1  a > b && b > c || c == 4 = %d\n", a > b && b > c || c == 4);
    printf("A2  a > c > b                = %d\n", a > c > b);
    return 0;
}
