#include <stdio.h>
int main(void)
{
    int units = 0;
    if (units = 5) {                      /* assignment, not comparison */
        printf("always true, units is now %d\n", units);
    }
    return 0;
}
