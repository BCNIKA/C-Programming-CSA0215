#include <stdio.h>
#include "billing_noguard.h"
#include "billing_noguard.h"

int main(void)
{
    printf("%d\n", BILLING_VERSION);
    return 0;
}
