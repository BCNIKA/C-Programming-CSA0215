#include <stdio.h>

int main(void)
{
    int    a = 10, b = 3, c = 4;
    double x = 2.5;
    int    units = 150;
    double rate = 8.50;
    int    p = 1, q = 2, r = 3;
    double d;

    printf("Initial: int a=10, b=3, c=4; double x=2.5; int units=150; double rate=8.50\n");
    printf("X1  a + b * c                    = %d\n", a + b * c);
    printf("X2  (a + b) * c                  = %d\n", (a + b) * c);
    printf("X3  a / b                        = %d\n", a / b);
    printf("X4  a %% b                        = %d\n", a % b);
    printf("X5  a / b * x                    = %.4f\n", a / b * x);
    printf("X6  a * x / b                    = %.4f\n", a * x / b);
    printf("X7  a / (b * x)                  = %.4f\n", a / (b * x));
    printf("X8  a - b - c                    = %d\n", a - b - c);
    printf("X9  a - (b - c)                  = %d\n", a - (b - c));
    printf("X10 ((a > b) && (b > c)) || (c == 4) = %d\n", ((a > b) && (b > c)) || (c == 4));
    printf("X11 (a > c) && (c > b)           = %d\n", (a > c) && (c > b));
    printf("X12 -a %% b                       = %d\n", -a % b);
    printf("X13 units * rate > 1000 && units %% 2 == 0 = %d\n", units * rate > 1000 && units % 2 == 0);
    p = q = r;
    printf("X14 p = q = r  (p=1,q=2,r=3)     -> p=%d q=%d r=%d\n", p, q, r);
    d = a / b;
    printf("X15 d = a / b  (d is double)     = %.1f\n", d);
    d = (double)a / b;
    printf("X16 d = (double)a / b            = %.4f\n", d);

    printf("--- common-error corrections ---\n");
    printf("7 / 2 = %d   but   7 / 2.0 = %.1f\n", 7 / 2, 7 / 2.0);
    {
        float wrong = 10 / 4;
        float right = 10 / 4.0f;
        printf("float wrong = 10 / 4 -> %.1f ; float right = 10 / 4.0f -> %.1f\n", wrong, right);
    }
    printf("a == 5 gives %d ; (a > b) && (b > c) gives %d\n", a == 5, (a > b) && (b > c));
    return 0;
}
