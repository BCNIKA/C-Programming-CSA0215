/*
 * File       : smart_campus_bill_v2.c
 * Purpose    : Task 12 - adds a department concession and a high-bill warning.
 * Author     : Yashwanth Bewan A (1921260214)
 * Build      : gcc -std=c11 -Wall -Wextra -pedantic smart_campus_bill_v2.c -o smart_campus_bill_v2
 * Assumptions: service charge 5%; concession 10% for department codes A and R;
 *              warning limit Rs. 5250.00 (all assumed values, not official rules).
 */
#include <stdio.h>
#include <ctype.h>

#define SERVICE_PERCENT 5.0              /* named constant: service charge in percent */
#define CONCESSION_PERCENT 10.0          /* NEW: concession in percent of gross bill  */
#ifndef WARNING_LIMIT                    /* NEW: configurable, e.g. -DWARNING_LIMIT=1000.0 */
#define WARNING_LIMIT 5250.00            /* warn when the final bill is ABOVE this    */
#endif

int main(void)
{
    char   facility_id[16];              /* identifier, at most 15 characters         */
    char   dept;                         /* NEW: A=Academic R=Research H=Hostel C=Commercial */
    int    units;                        /* whole units consumed                      */
    double rate;                         /* Rs. per unit                              */
    double subtotal, service_charge, final_bill;
    double gross_bill, concession;       /* NEW: bill before / amount of concession   */
    int    is_valid;                     /* 1 = valid billing record, 0 = invalid     */
    int    is_eligible;                  /* NEW: 1 = department gets the concession   */

    printf("=== SMART CAMPUS UTILITY BILLING SYSTEM (v2) ===\n");

    printf("Enter facility ID (no spaces):\n");
    if (scanf("%15s", facility_id) != 1) {
        printf("ERROR: facility ID is missing.\n");
        return 1;
    }
    printf("Enter department code (A, R, H or C):\n");
    if (scanf(" %c", &dept) != 1) {
        printf("ERROR: department code is missing.\n");
        return 1;
    }
    printf("Enter units consumed (whole number):\n");
    if (scanf("%d", &units) != 1) {
        printf("ERROR: units must be a whole number.\n");
        return 1;
    }
    printf("Enter rate per unit (Rs.):\n");
    if (scanf("%lf", &rate) != 1) {
        printf("ERROR: rate must be a number.\n");
        return 1;
    }

    dept = (char)toupper((unsigned char)dept);              /* accept a, r, h, c too */
    if (!((dept == 'A') || (dept == 'R') || (dept == 'H') || (dept == 'C'))) {
        printf("ERROR: department code must be A, R, H or C.\n");
        return 1;
    }

    is_valid = (units >= 0) && (rate >= 0.0);
    if (!is_valid) {
        printf("ERROR: units and rate must not be negative.\n");
        return 1;
    }

    is_eligible    = (dept == 'A') || (dept == 'R');        /* NEW: eligibility rule */

    subtotal       = units * rate;                          /* int is converted to double */
    service_charge = subtotal * SERVICE_PERCENT / 100.0;
    gross_bill     = subtotal + service_charge;             /* CHANGED: was final_bill   */
    concession     = is_eligible ? gross_bill * CONCESSION_PERCENT / 100.0 : 0.0;   /* NEW */
    final_bill     = gross_bill - concession;               /* NEW */

    if (final_bill < 0.0) {                                 /* defensive post-condition   */
        printf("ERROR: calculated bill is negative.\n");
        return 1;
    }

    printf("\n------------- BILL SUMMARY -------------\n");
    printf("Facility ID    : %s\n", facility_id);
    printf("Department     : %c (%s)\n", dept, is_eligible ? "eligible" : "not eligible");
    printf("Units consumed : %d\n", units);
    printf("Rate per unit  : Rs. %.2f\n", rate);
    printf("Subtotal       : Rs. %.2f\n", subtotal);
    printf("Service (%.1f%%) : Rs. %.2f\n", SERVICE_PERCENT, service_charge);
    printf("Gross bill     : Rs. %.2f\n", gross_bill);
    printf("Concession     : Rs. %.2f\n", concession);
    printf("FINAL BILL     : Rs. %.2f\n", final_bill);
    if (final_bill > WARNING_LIMIT) {                       /* NEW: warning, not an error */
        printf("WARNING: final bill exceeds the limit of Rs. %.2f\n", WARNING_LIMIT);
    }
    printf("----------------------------------------\n");
    return 0;
}
