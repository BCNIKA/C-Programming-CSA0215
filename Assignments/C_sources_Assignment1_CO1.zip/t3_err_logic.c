#include <stdio.h>

int main(void)
{
    int    units = 10;
    double rate = 8.5;
    double subtotal = units + rate;      /* should be units * rate */
    printf("Subtotal = %.2f\n", subtotal);
    return 0;
}
